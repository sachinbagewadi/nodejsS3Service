const express = require('express');
const bodyparser = require('body-parser');
const userRouter = require('./router/users')
const fileRouter = require('./router/files')

const app = express();

app.use(bodyparser.json());

app.use('/', userRouter);
app.use('/', fileRouter)

module.exports = app;