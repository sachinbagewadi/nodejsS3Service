const app = require('./app');

const port = 3000;

app.get('/', (req,res)=> {
    res.send('S3 service');
})

app.listen(port, ()=> {
    console.log('Server is running at port 3000')
})