const userModel = require('../model/users');

const userAuth = async (req, res, next) =>{
    try {
        const user_uuid = req.query.uuid;

        if (!user_uuid) {
            return res.json({ message: 'uuid is mandatory' })
        }

        const get_user = await userModel.findOne({ uuid: user_uuid })

        if (!get_user) {
            return res.json({
                message: "user not found"
            })
        }

        req.user = get_user
        next();

    } catch (error) {
        console.log(error)
    }
}
module.exports = userAuth;