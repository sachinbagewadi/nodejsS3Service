const uuid = require('uuid');
module.exports = {
    generateUUID: () => {
        return uuid.v4();
      },
}