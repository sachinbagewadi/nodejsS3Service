const fs = require('fs');
const router = require('express').Router();
const userAuth = require('../middleware/userAuth')
const path = require('path')
const upload = require('../middleware/multer')
const UploadModel = require('../model/files')

router.post("/createFolderBucket", userAuth, async (req, res) => {
    const folderName = req.body.folderName;
    if (!folderName) {
        return res.json({ message: "Folder Name is Mandatory" }).Code(499);
    }
    const rootFolder = "bucketFolder";
    const folderpath = `${rootFolder}/${folderName}`;
    try {
        if (fs.existsSync(rootFolder)) {
            if (!fs.existsSync(folderpath)) {
                fs.mkdirSync(folderpath);
                return res.json({ message: "Directory created" });
            }
        } else {
            fs.mkdirSync(rootFolder);
            if (!fs.existsSync(folderpath)) {
                fs.mkdirSync(folderpath);
                return res.json({ message: "Directory/Folder created" });
            }
        }
        return res.json({ message: "Directory/Folder Already Exist" });
    } catch (error) {
        console.log(error);
    }
});

router.get("/getAllFolderBucket", async (req, res) => {
    const directoryPath = path.join('bucketFolder');
    
    fs.readdir(directoryPath, (err, files) => {
        if (err) {
            console.error(err);
            return;
        }
        const directories = files.filter(file => {
            const filePath = path.join(directoryPath, file);
            return fs.statSync(filePath).isDirectory();
        });
        return res.json({ success: directories });
    });
});

router.post("/uploadFile", userAuth, upload().single("myFile"), async (req, res) => {
    if (req.file) {
        const filefullPath = req.file.destination + req.file.filename;
        console.log(filefullPath)
        const uploaded = new UploadModel({ user_id: req.user._id, file_name: req.file.filename, mime_type: req.file.mimetype, file_path: filefullPath });
        await uploaded.save();
        console.log('11', uploaded)
        res.json({ success: "File Uploaded Successfully" });
    }
});

router.get("/getAllFilesFromBucket", userAuth, async (req, res) => {
    try {
        const bucketName = req.body.bucketName;
        const directoryPath = path.join(`bucketFolder/${bucketName}`);
        fs.readdir(directoryPath, (err, files) => {
            if (err) {
                return res.json({ status: false, message: `${bucketName}, No Such Bucket Found` });
            }
            const allfiles = files.filter(file => {
                const filePath = path.join(directoryPath, file);
                return fs.statSync(filePath).isFile();
            });
            console.log(allfiles);
            return res.json({ status: true, filesList: allfiles });
        });
    } catch (error) {
        console.log("error------->>", error);
    }
});

router.get('/userFiles', userAuth, async(req,res)=> {
    try {


        const get_user_file = await UploadModel.find({user_id: req.user._id})

        res.json({files: get_user_file}) 
    } catch(error) {
        console.log(error)
    }
})

module.exports = router;