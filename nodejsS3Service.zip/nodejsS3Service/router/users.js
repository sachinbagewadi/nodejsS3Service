const router = require('express').Router();
const userModel = require('../model/users');
const common_service = require('../config/common_service')
const userAuth = require('../middleware/userAuth')

router.post('/register', async(req,res)=> {
    try {
        const {name} = req.body;
        var str = name + new Date().getTime;
        const uuid = common_service.generateUUID();

        const create_user = new userModel({name, uuid});
        await create_user.save();

        res.json({message:'User Created'})
    } catch (error) {
        console.log(error)
    }
});

router.post('/login', async(req,res, next)=> {
    try {

        const user_uuid = req.query.uuid;

        if(!user_uuid) {
            return res.json({message: 'uuid is mandatory'})
        }

        const get_user = await userModel.findOne({uuid: user_uuid})

        if(!get_user) {
            return res.json({
                message: "user not found"
            })
        }

        res.json({user: get_user}) 
        next();
    } catch(error) {
        console.log(error)
    }
})

module.exports = router;