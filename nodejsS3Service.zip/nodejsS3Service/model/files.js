const db = require('../config/db');
const mongoose = require('mongoose');
const {Schema} = mongoose;
const userModel = require('../model/users')

const filesSchema = new Schema({
    user_id:{
        type:Schema.Types.ObjectId,
        ref:userModel.modelName
    },
    file_name:{
        type:String
    },
    mime_type:{
        type:String
    },
    file_path:{
        type:String
    }
}, {timestamps:true});

const fileModel = db.model('files', filesSchema);

module.exports = fileModel;